<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Aidan Shene -->
    <meta charset="utf-8">
    <title><?php echo $title ?></title>
    <link rel="stylesheet" type="text/css" href="styles/main.css" media="screen">
</head>
<body class="grid">
<header class="navigation-sidebar-container">
    <nav class="navigation-sidebar">
        <ul class="navigation-sidebar-items">
            <li><a class="logo" href="index.php"></a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>
</header>